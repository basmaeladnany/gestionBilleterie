from django.contrib import admin
from .models import theme
# Register your models here.
admin.site.register(theme)
