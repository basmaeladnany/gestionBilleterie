from django.forms import ModelForm
from .models import theme

class themeform(ModelForm):
    class Meta:
        model= theme
        fields= '__all__'