from django.shortcuts import render,redirect
from .models import theme
from event.models import event
from .forms import themeform
# Create your views here.
def Theme(request):
    Theme=theme.objects.all()
    Event = event.objects.all()
    event.objects.filter(pk=request.GET.get('Theme.id'))
    context = {'Theme': Theme,'Event':Event}
    return render(request,'theme/acceuil.html',context)




