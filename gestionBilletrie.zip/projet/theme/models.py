from django.db import models
from django.utils import timezone
# Create your models here.

class theme(models.Model):
    Theme = models.TextField(max_length=200,null=True)



    def __str__(self):
        return self.Theme
