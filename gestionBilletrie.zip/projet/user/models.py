from django.contrib.auth.models import AbstractUser


class user(AbstractUser):
    pass








