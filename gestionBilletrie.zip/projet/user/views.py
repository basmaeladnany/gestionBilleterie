from django.shortcuts import render, redirect
from django.contrib.auth import get_user_model, login
# Create your views here.


User=get_user_model()
def user(request):
    if request.method=='POST':
        username=request.POST.get("username")
        password = request.POST.get("password")
        user = User.objects.create_user(username=username,password=password)
        login(request,user)
        return redirect('connexion')

    return render(request,'user/user.html')

def connexion(request):

    return render(request,'user/cnx.html')
