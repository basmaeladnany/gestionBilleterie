from django.urls import path
from . import views
from django.contrib import admin
name_app= 'user'

urlpatterns = [
    path('/inscription', views.user, name='inscription'),
    path('/connexion', views.connexion, name='connexion'),
]