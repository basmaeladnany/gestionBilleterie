from django.db import models
from django.utils import timezone

# Create your models here.
class billet(models.Model):
    Theme = models.TextField(max_length=200,null=True)

    Prix_ticket = models.FloatField(max_length=200,null=True)
    Date_evenement = models.DateTimeField(auto_now_add=True,null=True)

    def __str__(self):
        return self.Theme

