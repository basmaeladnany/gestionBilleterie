from django.contrib import admin
from .models import billet
# Register your models here.
admin.site.register(billet)
