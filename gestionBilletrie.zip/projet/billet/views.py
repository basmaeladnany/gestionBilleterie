from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from event.models import event
from theme.models import theme
# Create your views here.

def billet(request):
    Event = event.objects.all()
    Theme = theme.objects.all()
    event_found = "rien"
    for e in Event:
        if e.id == int(request.GET.get('id')):
            event_found = e
            break

    list_billet = []

    for b in billet:
        if b.Event == event_found:
            list_billet.append(b)

    return render(request,'billet/billet.html')

