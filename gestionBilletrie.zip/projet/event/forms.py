from django.forms import ModelForm
from .models import event

class eventform(ModelForm):
    class Meta:
        model= event
        fields= '__all__'