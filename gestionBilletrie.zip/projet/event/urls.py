from django.conf.urls.static import static
from django.urls import path
from . import views
from django.contrib import admin
from billet_event import settings

app_name= "event"

urlpatterns = [
    path('admin/', admin.site.urls ),
    path('', views.Event, name='event'),
    path('/affiche_event/', views.affiche_event, name='affiche_event'),
]+ static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)