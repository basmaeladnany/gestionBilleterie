from django.contrib import admin
from .models import event
# Register your models here.
admin.site.register(event)

