from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from theme.models import theme
# Create your models here.

class event(models.Model):
    Theme=models.ForeignKey(theme,null=True,on_delete=models.SET_NULL)
    Description = models.TextField(max_length=200,null=True)
    Images= models.ImageField(upload_to="static/images",blank=True,null=True)
    Prix_ticket = models.FloatField(max_length=200, null=True)
    date_event = models.DateTimeField(null=True)

    def __str__(self):
        return self.Description
