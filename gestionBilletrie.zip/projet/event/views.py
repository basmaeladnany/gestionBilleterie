from django.shortcuts import render,redirect
from .models import event
from theme.models import theme
from .forms import eventform
def Event(request):
    Event=event.objects.all()
    Theme=theme.objects.all()
    theme_found = "rien"
    for t in Theme:
        if t.id == int(request.GET.get('id')):
            theme_found = t
            break
    liste_event = []
    for e in Event:
        if e.Theme == theme_found:
            liste_event.append(e)
    context={'liste_event': liste_event, 'theme_found': theme_found,'Theme':Theme}
    return render(request,'event/event.html',context)


def affiche_event(request):
    Event=event.objects.all()
    context={'Event':Event}
    return render(request,'theme/acceuil.html',context)